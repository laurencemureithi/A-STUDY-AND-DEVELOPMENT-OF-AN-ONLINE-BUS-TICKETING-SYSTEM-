<h1> your signup was successful </h1>
<a href="login.php"> click here to login </a>